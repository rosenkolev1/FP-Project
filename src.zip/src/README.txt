words file taken from this page:
https://gist.github.com/dracos/dd0668f281e685bad51479e5acaadb93